# SV-DeckTracker
An automatic deck tracker for Shadowverse on Steam

## Intro

SV-DeckTracker is an automatic deck tracker for Shadowverse. It shows what cards are in your hand and what cards are left in the deck. Still fairly buggy at the moment, but works at the least. Only tested for windows at the moment. Please read the help text for all your questions!

## Compiling
- QT 5.7
- Windows functions

Compiled on Windows, 64 bit. Probably won't compile on linux/mac.
