#ifndef CARD_H
#define CARD_H
#include <QString>

struct Card{
    QString name;       //card name to display
    int manaCost;
    int ID;
    int clan;
};

#endif // CARD_H
